<?php include'header.php';?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <!-- <span class="pull-right"><a href="#">Home</a> / About Us</span> -->
    <h2>About Us</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="spacer">
<div class="row">
  <div class="col-lg-8  col-lg-offset-2">
  <img src="images/about.jpg" class="img-responsive thumbnail"  alt="realestate">
  <h3>Business Background</h3>
  <p>Focused in interpreting successful and inclusive services to Co-operative Housing Societies. We are the pioneers in On-screen Billing & Accounts Services to Housing Societies. With the changing scenario of increasing complexities in Housing Societies Management, we have professionalized Housing Societies Management.The Billing & Accounts combined with professional management has become strength of many of our clients. In a field where the Accountant / Manager normally changes along with a change in the Managing Committee, we have proved that this need not be the case. Possibly just because, we are not anybody's man. We are the Housing Society Management People.</p>
  <h3>Company Profile</h3>
  <p>We have also developed our own software to handle Billing and Accounts related requirements for our clients. This unique software also takes care of service tax matters of housing society. Our mission is to provide cost-effective, efficient and affordable "e-Housing Solution" to Co-operative Housing Societies in the city of Mumbai and outside area.</p>
  </div>
 
</div>
</div>
</div>

<?php include'footer.php';?>