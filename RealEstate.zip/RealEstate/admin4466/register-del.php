<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$q="delete from cust_regi where cust_id=".$_GET['cust_id'];
mysqli_query($c,$q);
header("location:register-detail.php");
?>