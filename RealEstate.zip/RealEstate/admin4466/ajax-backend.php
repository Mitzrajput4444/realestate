<?php 
include("conn.php");
$q="select * from cust_state";
$res=mysqli_query($c,$q);
$action="";
if(mysqli_num_rows($res)>0){
while($row=mysqli_fetch_assoc($res)){
    $action .= "<option value='{$row["state_id"]}'>{$row['state_name']}</option>";
}
echo $action;
}

else{
    echo "SORRY NO DATA FOUND";
}
?>