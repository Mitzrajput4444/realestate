<?php 
if($_SESSION['uname']== ""){
    header("location:index.php");
}
?>