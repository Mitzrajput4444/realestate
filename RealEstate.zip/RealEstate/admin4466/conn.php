<?php
$c=mysqli_connect("localhost","root","","ehousing");
if(!$c){
    die("not Connect");
}

?>