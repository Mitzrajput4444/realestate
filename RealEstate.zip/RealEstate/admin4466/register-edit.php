<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$qq="select * from cust_regi where cust_id=".$_GET['cust_id'];
$res=mysqli_query($c,$qq);
$row=mysqli_fetch_object($res);
if(isset($_REQUEST['btnsubmit']))
{
   $q="
  update cust_regi set 
  cust_name='".$_REQUEST['txtname']."',
  cust_email='".$_REQUEST['txtemail']."',
  cust_phone='".$_REQUEST['txtphone']."',
  cust_pass='".$_REQUEST['txtpass']."',
  cust_cpass='".$_REQUEST['txtcpass']."',
  cust_state='".$_REQUEST['txtstate']."',
  cust_city='".$_REQUEST['txtcity']."'
  where cust_id=".$_GET['cust_id'];
  mysqli_query($c,$q);

  header("location:register-detail.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <title>Regi-update</title>
</head>
<body>
    <div class="container">
    <hr/>
    <h2 align="center" class="m-4">REGESTRATION-UPDATE</h2>
    <hr/>
    <form method="post"> <div class="form-group">
    <label for="exampleInputEmail1">custent Name:</label>
    <input type="text" name="txtname" value="<?php echo $row->cust_name ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
   
  </div> <div class="form-group">
    <label for="exampleInputEmail1">custent Email:</label>
    <input type="email" name="txtemail" value="<?php echo $row->cust_email ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
   
  </div> <div class="form-group">
    <label for="exampleInputEmail1">custent Phone:</label>
    <input type="number" name="txtphone" value="<?php echo $row->cust_phone ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">custent Password:</label>
    <input name="txtpass" type="password" value="<?php echo $row->cust_pass ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">custent Confirm-Password:</label>
    <input name="txtcpass" type="password" value="<?php echo $row->cust_cpass ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">State:</label>
    <input name="txtstate" type="text" value="<?php echo $row->cust_state ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">City:</label>
    <input name="txtcity" type="text" value="<?php echo $row->cust_city ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
  </div>
  
 
  <br>
  
  <button type="submit" name="btnsubmit"class="btn btn-primary">Submit</button>
  <button type="submit" name="btn-back"class="btn btn-primary">Back</button>
</form>
    </div>
</body>
</html>