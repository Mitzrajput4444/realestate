<?php 
session_start();
include('uncheckforsession.php');
include('conn.php');
$q="select * from cust_city";
$res=mysqli_query($c,$q);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css"/>
    <link href="//cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <title>city-info</title>
</head>
<body>
   <div class="container">
       <hr/>
    <h2 align="center" class="m-2">CITY-DETAILS</h2>
    <hr/>
    
    <div class="mb-4 d-flex justify-content-between">
    <span style="color:slategray"> Welcome &nbsp;<?php echo $_SESSION['uname']; ?></span>
    <div>
            <a class="btn btn-primary" href="./register-detail.php">HOME</a> 
            <a class="btn btn-primary" href="../register.php">ADD</a> 
            <a class="btn btn-primary" href="./notified-email.php">NITIFIED-EMAIL</a> 
            <a class="btn btn-primary" href="./post-inquiry.php">POST-INQUIRY</a> 
        <a class="btn btn-primary" href="./logout.php">LOGOUT</a> 
    </div>
    </div>
   <table id="myTable" class="table mt-4 table-striped table-hover">
        <thead>
            <tr align="center" >
                <th>city-Id</th>
                <th>city-Name</th>
                <th>state-ID</th>
                <th>EDIT</th>  
                <th>DELETE</th>   
            </tr>
            </thead>
            <tbody>

                <?php 
            while($row=mysqli_fetch_object($res)){
                ?>
            <tr align="center">
                <td><?php echo $row->city_id; ?></td>
                <td><?php echo $row->city_name; ?></td>
                <td><?php echo $row->state_id; ?></td>
                <td><a class="btn btn-primary" href="city-edit.php?id=<?php echo $row->city_id; ?>">EDIT</a></td>  
                <td><a class="btn btn-danger" href="city-del.php?id=<?php echo $row->city_id; ?>" onclick="return confirm('ARE YOU WANT TO SURE..?')">DELETE</a></td>  
            </tr>
            <?php } ?>
        </tbody>
    </table>
   </div>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
   <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
   <script>
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
</body>
</html>