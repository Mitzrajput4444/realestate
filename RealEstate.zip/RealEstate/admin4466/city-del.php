<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$q="delete from cust_city where city_id=".$_GET['id'];
mysqli_query($c,$q);
header("location:city-info.php");
?>