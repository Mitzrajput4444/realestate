<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$q="delete from cust_state where state_id=".$_GET['id'];
mysqli_query($c,$q);
header("location:state-info.php");
?>