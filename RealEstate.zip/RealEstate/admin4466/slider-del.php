<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$q="delete from slider_info where slider_id=".$_GET['id'];
mysqli_query($c,$q);
header("location:slider-info.php");
?>