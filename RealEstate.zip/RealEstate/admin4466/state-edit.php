<?php
session_start();
include('uncheckforsession.php');
include('conn.php');
$show="select * from cust_state where state_id=".$_GET['id'];
$res=mysqli_query($c,$show);
$row=mysqli_fetch_object($res);
if(isset($_REQUEST['btn-submit'])){
    $q="update cust_state set 
    state_name='".$_REQUEST['txtname']."' where state_id=".$_GET['id'];
    mysqli_query($c,$q);
    header("location:state-info.php");

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <title>Regi-update</title>
</head>
<body>
    <div class="container">
    <hr/>
    <h2 align="center" class="m-4">STATE-UPDATE</h2>
    <hr/>
    <form method="post"> <div class="form-group">
    <label for="exampleInputEmail1">custent Name:</label>
    <input type="text" name="txtname" value="<?php echo $row->state_name ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  
  <button type="submit" name="btn-submit"class="btn btn-primary">Submit</button>
  <button type="submit" name="btn-back"class="btn btn-primary">Back</button>
</form>
    </div>
</body>
</html>