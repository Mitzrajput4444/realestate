<?php 
session_start();
if($_SESSION['cust_email'] == ""){
    header("location:index.php");
}

?>