<?php include'header.php';?>
<?php include'slider.php';?>
<?php include'buysalerentslide.php';?>
<?php include'feature.php';?>
<?php include'reccomendedprops.php';?>
<?php include'footer.php';?>