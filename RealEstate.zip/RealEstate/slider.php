<?php
include("./admin4466/conn.php");
$q="select * from slider_info";
$res=mysqli_query($c,$q);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slider</title>
</head>
<body>
<div class="">
    

    <div id="slider" class="sl-slider-wrapper">

<div class="sl-slider">
<?php 
  while($row=mysqli_fetch_object($res)){

  
?>
  <div class="sl-slide" data-orientation="<?php echo $row->slider_animation ?>" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
    <div class="sl-slide-inner">
    <div><img class="bg-img" src="./admin4466/uploadimage/<?php echo $row->slider_img ?>"/></div>
      <h2><a href="#"><?php echo $row->slider_name ?></a></h2>
      <blockquote>              
      <p class="location"><span class="glyphicon glyphicon-map-marker"></span> <?php echo $row->slider_location ?></p>
      <p><?php echo $row->slider_desc ?></p>
      <button class="mybg">&#8377; <?php echo $row->slider_price ?></button>
      </blockquote>
    </div>
  </div>
  <?php 
  } 
  ?>

  <!-- <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
    <div class="sl-slide-inner">
      <div><img class="bg-img" src="./images/slider/2.jpg"/></div>
      <h2><a href="#">4 Bed Rooms and 2 Dinning Room Aparment on Sale</a></h2>
      <blockquote>              
      <p class="location"><span class="glyphicon glyphicon-map-marker"></span> 2023 Jaipur, Rajasthan</p>
      <p>Until he extends the circle of his compassion to all living things, man will not himself find peace.</p>
      <button class="mybg">&#8377; 50,000,00</button>
      </blockquote>
    </div>
  </div>
  
  <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="3" data-slice2-rotation="3" data-slice1-scale="2" data-slice2-scale="1">
    <div class="sl-slide-inner">
    <div><img class="bg-img" src="./images/slider/3.jpg"/></div>
      <h2><a href="#">6 Bed Rooms and 2 Dinning Room Aparment on Sale</a></h2>
      <blockquote>              
      <p class="location"><span class="glyphicon glyphicon-map-marker"></span> 2022 panjim, Goa</p>
      <p>Until he extends the circle of his compassion to all living things, man will not himself find peace.</p>
      <button class="mybg">&#8377; 20,000,00</button>
      </blockquote>
    </div>
  </div>
  
  <div class="sl-slide" data-orientation="vertical" data-slice1-rotation="-5" data-slice2-rotation="25" data-slice1-scale="2" data-slice2-scale="1">
    <div class="sl-slide-inner">
    <div><img class="bg-img" src="./images/slider/4.jpg"/></div>
      <h2><a href="#">3 Bed Rooms and 2 Dinning Room Aparment on Sale</a></h2>
      <blockquote>              
      <p class="location"><span class="glyphicon glyphicon-map-marker"></span> 2023 pune, Maharashtra</p>
      <p>Until he extends the circle of his compassion to all living things, man will not himself find peace.</p>
      <button class="mybg">&#8377; 150,00,000</button>
      </blockquote>
    </div>
  </div>
  
  <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-5" data-slice2-rotation="10" data-slice1-scale="2" data-slice2-scale="1">
    <div class="sl-slide-inner">
    <div><img class="bg-img" src="./images/slider/5.jpg"/></div>
      <h2><a href="#">2 Bed Rooms and 1 Dinning Room Aparment on Sale</a></h2>
      <blockquote>              
      <p class="location"><span class="glyphicon glyphicon-map-marker"></span> 2022 Surat, Gujarat</p>
      <p>Until he extends the circle of his compassion to all living things, man will not himself find peace.</p>
      <button class="mybg">&#8377; 75,000,000</button>
      </blockquote>
    </div>
  </div> -->
</div>
<!-- /sl-slider -->



<nav id="nav-dots" class="nav-dots">
  <span class="nav-dot-current"></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</nav>

</div><!-- /slider-wrapper -->
</div>
</body>
</html>