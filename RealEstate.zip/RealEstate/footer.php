<?php 
include("./admin4466/conn.php");
$m="";
$msg="";
if(isset($_REQUEST['btn-submit'])){
  if($_REQUEST['nemail'] == ""){
    $msg="Not Valid";
  }
  else{

    $q="insert into notified_email set 
  notified_email = '".$_REQUEST['nemail']."'
  ";
  mysqli_query($c,$q);
  }

}

// login 
if(isset($_REQUEST['btn-login'])){
  $email=$_REQUEST['email'];
  $pass=$_REQUEST['password'];
  $q="select * from cust_regi where cust_email='$email' && cust_pass='$pass'";
$res=mysqli_query($c,$q);
$row=mysqli_fetch_array($res);
$name=$row['cust_name'];
$n=mysqli_num_rows($res);
echo $n;
if($n==1){
  // header("loction:index-cust.php");
  ?>
  <script> location.replace('buysalerent.php');</script>
  <?php 
  $m="<span style='color:green'>Welcome $name</span>";

}
else{
  $m="<span style='color:red'>FIRST REGISTRATION</span>";
}
// if(isset($_REQUEST['checkrem'])){
//   setcookie("email",$_REQUEST['email'],time()+60);
//   setcookie("pass",$_REQUEST['password'],time()+60);
// }
}
// if(isset($_COOKIE['email']))
// $u=$_COOKIE['email'];

// else
// $u="";

// if(isset($_COOKIE['pass']))
// $p=$_COOKIE['pass'];

// else
// $p="";
?>

<div class="footer">

<div class="container">



<div class="row">
            <div class="col-lg-3 col-sm-3">
                   <h4>Information</h4>
                   <ul class="row">
                <li class="col-lg-12 col-sm-12 col-xs-3"><a href="about.php">About</a></li>
                <li class="col-lg-12 col-sm-12 col-xs-3"><a href="agents.php">Agents</a></li>         
                <li class="col-lg-12 col-sm-12 col-xs-3"><a href="blog.php">Blog</a></li>
                <li class="col-lg-12 col-sm-12 col-xs-3"><a href="contact.php">Contact</a></li>
              </ul>
            </div>
            
            <div class="col-lg-3 col-sm-3">
                    <h4>Newsletter</h4>
                    <p>Get notified about the latest properties in our marketplace.</p>
                    <!-- <span>msg</span> -->
                    <form method="post" class="form-inline" role="form">
                      <p><?php echo $msg; ?></p>
                            <input name="nemail" type="email" placeholder="Enter Your email address" class="form-control" required>
                                <button class="btn btn-success" type="submit" name="btn-submit">Notify Me!</button></form>
            </div>
            
            <div class="col-lg-3 col-sm-3">
                    <h4>Follow us</h4>
                    <a href="https://facebook.com/"><img src="images/facebook.png" alt="facebook"></a>
                    <a href="https://twitter.com/"><img src="images/twitter.png" alt="twitter"></a>
                    <a href="https://linkedin.com/"><img src="images/linkedin.png" alt="linkedin"></a>
                    <a href="https://instagram.com/"><img src="images/instagram.png" alt="instagram"></a>
            </div>

             <div class="col-lg-3 col-sm-3">
                    <h4>Contact us</h4>
                    <p><b>MP Realestate Inc.</b><br>
<span class="glyphicon glyphicon-map-marker"></span> 144 Luhar Street, India <br>
<span class="glyphicon glyphicon-envelope"></span> gohilmittal144@gmail.com<br>
<span class="glyphicon glyphicon-earphone"></span> (+91) 99799 45258</p>
            </div>
        </div>
<p class="copyright">Copyright 2023. All rights reserved.	</p>


</div></div>




<!-- Modal -->
<div id="loginpop" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="row">
        <div class="col-sm-6 login">
        <h4>Login</h4> <?php echo $m; ?>
          <form method="post" role="form">
        <div class="form-group">
          <label class="sr-only" for="exampleInputEmail2">Email address</label>
          <input type="email" class="form-control" id="exampleInputEmail2" value="" name="email" placeholder="Enter email" required>
        </div>
        <div class="form-group">
          <label class="sr-only" for="exampleInputPassword2">Password</label>
          <input type="password" class="form-control" id="exampleInputPassword2" value="" name="password"placeholder="Password" required>
        </div>
        <div class="checkbox">
          <label>
            <input type="checkbox" name="checkrem"> Remember me
          </label>
        </div>
        <button type="submit" name="btn-login" class="btn btn-success">Sign in</button>
      </form>          
        </div>
       <div class="col-sm-6">
          <h4>New User Sign Up</h4>
          <p>Join today and get updated with all the properties deal happening around.</p>
          <button type="submit" class="btn btn-info btn-my2" name="btn-submit-regi"  onclick="window.location.href='register.php'">Join Now</button>
        </div>

      </div>
    </div>
  </div>
</div>
</body>
</html>



